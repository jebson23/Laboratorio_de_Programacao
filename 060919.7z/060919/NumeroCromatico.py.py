grafo = []
cores = []
vertice_e_gral = {}
painted = {}

n = int(input("Informe a quantidade de Vertices do grafo: "))

for i in range(n):
	arestas = input("informe as arestas do {} vertice: ".format(i + 1)).split(' ')
	grafo.append(arestas)
	vertice_e_gral[i] = arestas
	cores.append(i)

gralOrdenado = sorted(list(vertice_e_gral.keys()), key = lambda x: len(vertice_e_gral[x]), reverse = True)

for indice in gralOrdenado:
	if indice in painted:
		continue
	
	else:
		auxiliar = grafo[indice]
		for i in cores:
			seguir = True
			for j in auxiliar:
				j = int(j)
				
				if j not in painted:
					continue
				
				else:
					if i == painted[j]:
						seguir = False
						break
			if seguir == False:
				continue

			else:
				painted[indice] = i
				break

coresUsadas = painted.values()

print("A quantidade de cores Usadas foram: {}".format(max(coresUsadas) + 1))			

