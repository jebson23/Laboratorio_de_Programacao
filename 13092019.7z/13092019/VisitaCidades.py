n, a, b = map(int, input("Informe os valores N, A e B(Separe os valores com espac4o em branco):").split(' '))           #N A e B são numeros inteiros com N > 2, 1 ≤ A ≤ N, 1 ≤ B ≤ N, A ≠ B

grafo = [[] for i in range(n)]                                                                                          #Cria uma lista de tamanho N, onde cada indice dessa lista representa uma cidade e contem outra lista vazia que será preenchida com as cidades com quem se liga e os custos.
percorridos = [0 for i in range(n)]                                                                                     #Cria uma lista de tamanho N, preenchida com zeros, essa lista serve para fazer o controle das cidades ja percorridas.

for i in range(n - 1):
    p, q, d = map(int, input("Informe os valores P, Q e D(Separe os valores com espaco em branco):").split(' '))        #1 ≤ P ≤ N, 1 ≤ Q ≤ N , 1 ≤ D ≤ 100
    grafo[p - 1].append((q - 1, d))                                                                                     #Salva no indice p - 1 da lista uma tupla contendo a cidade com quem aquele indice se liga e o peso da ligação.
    grafo[q - 1].append((p - 1, d))                                                                                     #Salva no indice q - 1 da lista uma tupla contendo a cidade com quem aquele indice se liga e o peso da ligação.

caminho = [(a - 1, 0)]                                                                                                  #Essa lista recebe as cidades que estou percorrendo no caminho e o custo total ate o momento.

while caminho != []:
    auxiliar = caminho.pop(0)                                                                                           #Essa variavel guarda o que esta na posição zero da lista caminho e apaga esse conteudo da mesma.
    percorridos[auxiliar[0]] = 1                                                                                        #Altera para 1 o  conteudo na lista percorridos referente ao indice obtido na posição zero da variavel auxilar, isso serve para marcar que aquela indice já foi percorrido.
    if auxiliar[0] == b - 1:
        print(auxiliar[1])                                                                                              #Se a condição for verdedeira o custo salvo na posição 1 da variavel auxiliar é printado.
        break

    else:
        for i in grafo[auxiliar[0]]:                                                                                    #percorre todos os vizinhos da ultima cidade testada.
            if percorridos[i[0]] == 0:
                caminho.append((i[0], auxiliar[1] + i[1]))                                                              #se a condição for verdadeira significa que essa cidade ainda nao foi percorrida, e ela é adicionada na lista caminho para ser testada futuramente.
            else:
                continue